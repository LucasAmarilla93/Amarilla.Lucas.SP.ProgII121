package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import modelo.Animal;
import modelo.Clasificable;
import modelo.TipoAlimentacion;

/*
Agregar animales al inventario. 
o Obtener animales por índice. 
o Eliminar animales por índice. 
o Filtrar animales según un criterio (como por ejemplo, por tipo de alimentación o 
especie). 
o Ordenar animales: 
▪ Ordenar de manera natural (por id). 
▪ Ordenar mediante un Comparator (por ejemplo, por nombre o especie). 
o Guardar el inventario de animales en un archivo binario. 
o Cargar el inventario de animales desde un archivo binario. 
o Guardar el inventario de animales en un archivo CSV. 
o Cargar el inventario de animales desde un archivo CSV.

*/
public class GestorZoologico {
    

    public static <T> void MostrarContenido(Clasificable<T> clasificable) {
        Iterator<T> iterador = clasificable.iterator();
        while (iterador.hasNext()) { 
            System.out.println(iterador.next());
        }
    }
    
    public static <T> List<T> filtrarZoo(Clasificable<T> clasificable, Predicate<? super T> criterio){
        return clasificable.filtrar(criterio);
    }
    
    public static <T> void paraCadaItem(Clasificable<T> clasificable, Consumer<? super T> accion){
        clasificable.paraCadaElemento(accion);
    }
    
    
     public static void validarArchivo(String path){
        File archivo = new File(path);
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");
            } else {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Ocurrio un error al crear el archivo.");
        }
    }
  
}
