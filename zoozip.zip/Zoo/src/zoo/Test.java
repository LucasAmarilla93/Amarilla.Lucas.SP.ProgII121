package zoo;

import java.io.IOException;
import java.util.List;
import modelo.Animal;
import modelo.TipoAlimentacion;
import modelo.Zoologico;
import servicio.GestorZoologico;


public class Test {

    public static void main(String[] args) {

      //  try {
            //Crear un zoológico de animales
            Zoologico<Animal> zoologico = new Zoologico<>();
            zoologico.agregar(new Animal(1, "Leon", "Panthera leo",TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(4, "Elefante", "Loxodonta",TipoAlimentacion.HERBIVORO));
            zoologico.agregar(new Animal(3, "Oso", "Ursus arctos",TipoAlimentacion.OMNIVORO));
            zoologico.agregar(new Animal(7, "Zorro", "Vulpes vulpes",TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(5, "Gorila", "Gorilla gorilla",TipoAlimentacion.OMNIVORO));
            separador();
            
            // Mostrar todos los animales en el zoológico 
            System.out.println("Inventario de animales:"); 
            zoologico.paraCadaElemento(animal -> System.out.println(animal));
            separador();
            
            
            // Filtrar animales por tipo de alimentación CARNIVORO 
            System.out.println("\nAnimales CARNIVOROS:"); 
            GestorZoologico.filtrarZoo(zoologico, (a -> a.getAlimentacion().equals(TipoAlimentacion.CARNIVORO))).forEach(animal -> System.out.println(animal));
           
             // Filtrar animales cuyo nombre contiene "Leon" 
            System.out.println("\nAnimales cuyo nombre contiene 'Leon':"); 
            GestorZoologico.filtrarZoo(zoologico, (a -> a.getNombre().equals("Leon"))).forEach(animal -> System.out.println(animal));
            separador();
            
            //RESOLVER ESTA PARTE//////////////////////////////////////////////////////////////
            // Ordenar animales de manera natural (por id) 
            System.out.println("\nAnimales ordenados de manera natural (por id):"); 
            GestorZoologico.MostrarContenido(zoologico);

            // Ordenar animales por nombre utilizando un Comparator     
            System.out.println("\nAnimales ordenados por nombre:"); 
            
            ////////////////////////////////////////////////////////////////////////////////////
           
            
            // Guardar el zoológico en un archivo binario 
            zoologico.guardarEnArchivo("src/data/animales.dat");

            // Cargar el zoológico desde el archivo binario 
            Zoologico<Animal> zoologicoCargado = zoologico.cargarDesdeArchivo("src/data/animales.dat"); 
            System.out.println("\nAnimales cargados desde archivo binario:");  
            zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));  
            

            // Guardar el zoológico en un archivo CSV 
            zoologico.guardarEnCSV("src/data/animales.csv"); 
            // Cargar el zoológico desde el archivo CSV 
            Zoologico<Animal> zoologicoCSV = zoologico.cargarDesdeCSV("src/data/animales.csv"); 
            System.out.println("\nAnimales cargados desde archivo CSV:"); 
            zoologicoCSV.paraCadaElemento(System.out::println);

            
            
     /*   } catch (IOException | ClassNotFoundException ex) {
            System.err.println("Error: " + ex.getMessage());
        }*/
    }

    public static void separador(){
        System.out.println("---------------------------------------------------------------------------------------------------");
    }
}
