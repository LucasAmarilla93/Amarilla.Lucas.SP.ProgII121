package modelo;

import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/*
Agregar animales al inventario. 
o Obtener animales por índice. 
o Eliminar animales por índice. 


o Filtrar animales según un criterio (como por ejemplo, por tipo de alimentación o 
especie). 
o Ordenar animales: 
▪ Ordenar de manera natural (por id). 
▪ Ordenar mediante un Comparator (por ejemplo, por nombre o especie).


o Guardar el inventario de animales en un archivo binario. 
o Cargar el inventario de animales desde un archivo binario. 


o Guardar el inventario de animales en un archivo CSV. 
o Cargar el inventario de animales desde un archivo CSV.

*/
public interface Clasificable<T> extends Iterable<T> {
    
    void agregar (T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    void paraCadaElemento(Consumer<? super T> accion);
    
}
