package modelo;

import java.io.Serializable;
import java.util.Objects;
import servicio.CSVSerializable;

/*Animal: Debe contener los siguientes atributos: id (entero), nombre (String), 
especie (String) y alimentacion (enum TipoAlimentacion). La clase Animal debe 
implementar Comparable<Animal> para que se pueda ordenar de manera natural 
por su id (en orden ascendente). 
*/
public class Animal implements Comparable<Animal>, Serializable, CSVSerializable{
    
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
    }

    @Override
    public int compareTo(Animal otherAnimal) {     
        return Integer.compare(id, otherAnimal.id);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public String toCSV(){
        return getId() + "," + getNombre() + "," + getEspecie() + "," + getAlimentacion();
        
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null) {
            return false;
        }

        if (this.getClass() != o.getClass()) {
            return false;
        }

        Animal otherAnimal = (Animal) o;
        return this.nombre.equals(otherAnimal.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
}
