package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import servicio.CSVSerializable;

/*Zoologico: Implementa un inventario genérico que pueda almacenar cualquier 
tipo de objeto que implemente la interfaz CSVSerializable. 
El zoológico debe permitir agregar, eliminar, obtener elementos, y filtrar según un criterio. También 
debe permitir ordenar los animales de manera natural (por id) y a través de un 
Comparator (por ejemplo, por nombre o especie). 
 */
public class Zoologico<T> implements Clasificable<T>, Serializable {

    private List<T> lista = new LinkedList<>();

    private void validarRangoIndice(int indice) {
        if (indice < 0 || indice >= lista.size()) {
            throw new IndexOutOfBoundsException("El indice debe ser mayor a 0");
        }
    }

    private void validarNulidad(T item) {
        if (item == null) {
            throw new NullPointerException("El item es nulo");
        }
    }

    private void validarListaVacia() {
        if (lista.isEmpty()) {
            throw new RuntimeException("La lista esta vacia");
        }

    }

    public void setLista(List<T> lista) {
        this.lista = lista;
    }

    @Override
    public void agregar(T item) {
        validarNulidad(item);
        lista.add(item);
    }

    @Override
    public T obtener(int indice) {
        validarListaVacia();
        validarRangoIndice(indice);
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        validarListaVacia();
        validarRangoIndice(indice);
        lista.remove(indice);
    }

    private boolean validarIterator() {
        return !lista.isEmpty() && lista.get(0) instanceof Comparable;
    }

    ///////////////////////////Iterator//////////////////////////////////////////////////
    @Override
    public Iterator<T> iterator() {
        if (validarIterator()) {
            return iteratorNatural();
        }
        return lista.iterator();
    }

    public Iterator<T> iteratorNatural() { //Si hay instancia de Comparable, significa que se ordena de manera natural.
        List<T> aux = new ArrayList<>(lista);
        aux.sort(null);
        return aux.iterator();
    }

    //Sobrecarga de iterator.
    public Iterator<? extends T> iterator(Comparator<? super T> comparador) {
        if (validarIterator()) {
            return iteratorNatural();
        }
        return lista.iterator();
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item : lista) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : lista) {
            accion.accept(item);
        }
    }

    public void ordenar() {
        Iterator<T> iterador = lista.iterator();
        while (iterador.hasNext()) {
            System.out.println(iterador.next());
        }
    }

    private void validarArchivo(String path) {
        File archivo = new File(path);
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");
            } else {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Ocurrio un error al crear el archivo.");
        }
    }

    public void guardarEnCSV(String path) {
        validarArchivo(path);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,especie,alimentacion\n");
            for (T animal : lista) {
                try {
                    bw.write(((Animal) animal).toCSV() + "\n");
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            };

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public Zoologico cargarDesdeCSV(String path) {
        validarArchivo(path);
        Zoologico zoologicoCargado = new Zoologico();
        List<Animal> toReturn = new ArrayList<>();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                if (linea.endsWith("\n")) {
                    linea = linea.substring(linea.length() - 1);
                }
                String[] data = linea.split(",");
                if (data.length == 4) {
                    int id = Integer.parseInt(data[0]);
                    String nombre = data[1];
                    String especie = data[2];
                    TipoAlimentacion tipo = TipoAlimentacion.valueOf(data[3]);
                    Animal a = new Animal(id, nombre, especie, tipo);
                    toReturn.add(a);
                }
            }
            zoologicoCargado.setLista(toReturn);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return zoologicoCargado;
    }

    public void guardarEnArchivo(String path) {
        try (FileOutputStream archivo = new FileOutputStream(path); ObjectOutputStream salida = new ObjectOutputStream(archivo) {
        }) {
            salida.writeObject(lista);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public Zoologico cargarDesdeArchivo(String path) {
        List<Animal> toReturn = new ArrayList<>();
        Zoologico zoo = new Zoologico();
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Animal>) input.readObject();
            zoo.setLista(toReturn);
        } catch (IOException | ClassNotFoundException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
        return zoo;
    }
}
